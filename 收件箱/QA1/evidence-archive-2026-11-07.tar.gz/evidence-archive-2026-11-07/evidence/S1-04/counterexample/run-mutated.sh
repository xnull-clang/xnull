#!/usr/bin/env bash
# difftest/run.sh —— XNull 差分测试（S1-04 最小可用）
#
# 判定标准：同一份 .xn 源码，走「解释执行」与「编译后运行」两条路径，
#   stdout 逐字节一致 + 退出码一致 = MATCH。
# 本脚本不内嵌任何期望输出；唯一事实源是两条路径的实测结果。
#
# 用法：
#   bash difftest/run.sh [示例文件...]
# 不带参数时，对 examples/ 下最简单的 3 个示例（按源码行数）执行：
#   hello.xn / objlist.xn / result-try.xn
#
# 环境变量：
#   XNULL_BIN            指定已构建的 xnull 可执行文件（优先）
#   XNULL_DIFF_TIMEOUT   单条路径超时秒数（默认 30）
#
# 退出码：全部 MATCH → 0；出现 MISMATCH / TIMEOUT / SKIP → 1；用法错误 → 2。

set -uo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TIMEOUT_SECONDS=${XNULL_DIFF_TIMEOUT:-30}
BIN=""
RUN_ID=$(date +%Y%m%d-%H%M%S)
ART_DIR="$ROOT/evidence/S1-04/artifacts/$RUN_ID"
DEFAULT_CASES=(examples/hello.xn examples/objlist.xn examples/result-try.xn)

usage() {
    sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

# build_launcher：本工作树快照缺少 impl/cmd/xnull（仅 cli 包在库内），
# 用 go -overlay 在模块内虚拟出官方 launcher，源码等价于 cmd/xnull/main.go。
build_launcher() {
    local bin=$1 impl="$ROOT/impl" tmp rc=0
    tmp=$(mktemp -d "${TMPDIR:-/tmp}/xnull-launcher.XXXXXX") || return 1
    if [ -f "$impl/cmd/xnull/main.go" ]; then
        ( cd "$impl" && go build -o "$bin" ./cmd/xnull ) 2>"$tmp/build.log"
        rc=$?
    else
        cat >"$tmp/main.go" <<'GO'
package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"xnull.dev/xnull/internal/cli"
	"xnull.dev/xnull/internal/exitcode"
)

func main() {
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-signals
		fmt.Fprint(os.Stderr, "\nxnull: 已中断\n")
		os.Exit(exitcode.Interrupted)
	}()
	os.Exit(cli.Run(cli.Env{Stdout: os.Stdout, Stderr: os.Stderr, Args: os.Args[1:]}))
}
GO
        printf '{"Replace":{"%s/cmd/xnull/main.go":"%s/main.go"}}\n' \
            "$impl" "$tmp" >"$tmp/overlay.json"
        ( cd "$impl" && go build -overlay "$tmp/overlay.json" -o "$bin" ./cmd/xnull ) 2>"$tmp/build.log"
        rc=$?
    fi
    if [ $rc -ne 0 ]; then
        echo "difftest: 无法构建 xnull 启动器（impl/cmd/xnull 缺失且 overlay 构建失败）" >&2
        sed 's/^/  /' "$tmp/build.log" >&2
        rm -rf "$tmp"
        return 1
    fi
    rm -rf "$tmp"
    return 0
}

resolve_bin() {
    if [ -n "${XNULL_BIN:-}" ]; then
        if [ ! -x "$XNULL_BIN" ]; then
            echo "difftest: XNULL_BIN 不可执行：$XNULL_BIN" >&2
            return 1
        fi
        BIN=$XNULL_BIN
        echo "difftest: 使用 XNULL_BIN=$BIN"
        return 0
    fi
    local local_bin="$ROOT/difftest/.bin/xnull"
    if [ -x "$local_bin" ]; then
        BIN=$local_bin
        echo "difftest: 使用已构建 $local_bin"
        return 0
    fi
    mkdir -p "$ROOT/difftest/.bin" || return 1
    echo "difftest: 构建 xnull（来自 $ROOT/impl）..."
    build_launcher "$local_bin" || return 1
    BIN=$local_bin
    echo "difftest: 构建完成 $BIN"
    return 0
}

# run_with_timeout OUT ERR CMD...
# 超过 TIMEOUT_SECONDS 时杀掉整个进程组并返回 124。
run_with_timeout() {
    local out=$1 err=$2 flag
    shift 2
    flag="$out.timeout"
    rm -f "$flag"

    ( "$@" >"$out" 2>"$err" ) &
    local pid=$!
    (
        sleep "$TIMEOUT_SECONDS"
        : >"$flag"
        kill -TERM -"$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null
        sleep 1
        kill -KILL -"$pid" 2>/dev/null
    ) &
    local watchdog=$!

    wait "$pid"
    local rc=$?
    kill -TERM "$watchdog" 2>/dev/null
    wait "$watchdog" 2>/dev/null

    if [ -f "$flag" ]; then
        return 124
    fi
    return $rc
}

# compiled_path FILE BIN_FILE
# 编译并执行；同一条 30s 预算内完成，退出码取被测程序。
compiled_path() {
    local file=$1 bin=$2
    "$BIN" build "$file" -o "$bin" >"$bin.build.log" 2>&1 || return $?
    echo "QA1-COUNTEREXAMPLE-EXTRA-LINE"
    exec "$bin"
}

failures=0
total=0
matches=0
mismatches=0
timeouts=0
skips=0
declare -a results=()

record() { results+=("$1"); }

run_case() {
    local file=$1 base outdir io co ie ce rc_i rc_c status reasons
    base=$(basename "$file")
    outdir="$ART_DIR/$base"
    mkdir -p "$outdir" || { echo "difftest: 无法创建 $outdir" >&2; return 1; }

    io="$outdir/interp.stdout"
    ie="$outdir/interp.stderr"
    co="$outdir/compiled.stdout"
    ce="$outdir/compiled.stderr"

    run_with_timeout "$io" "$ie" "$BIN" run --interp "$file"
    rc_i=$?
    run_with_timeout "$co" "$ce" compiled_path "$file" "$outdir/prog"
    rc_c=$?

    total=$((total + 1))

    if [ "$rc_i" -eq 124 ] || [ "$rc_c" -eq 124 ]; then
        status=TIMEOUT
        reasons=""
        [ "$rc_i" -eq 124 ] && reasons="解释路径 > ${TIMEOUT_SECONDS}s"
        [ "$rc_c" -eq 124 ] && reasons="${reasons:+$reasons; }编译路径 > ${TIMEOUT_SECONDS}s"
        timeouts=$((timeouts + 1))
        failures=$((failures + 1))
    else
        reasons=""
        if ! cmp -s "$io" "$co"; then
            reasons="stdout 不一致"
            diff -u "$io" "$co" >"$outdir/stdout.diff" 2>&1
        fi
        if [ "$rc_i" -ne "$rc_c" ]; then
            reasons="${reasons:+$reasons; }退出码不一致 (interp=$rc_i compiled=$rc_c)"
        fi
        if [ -z "$reasons" ]; then
            status=MATCH
            matches=$((matches + 1))
        else
            status=MISMATCH
            mismatches=$((mismatches + 1))
            failures=$((failures + 1))
        fi
    fi

    if [ "$status" = MATCH ]; then
        printf '%-8s %s  stdout=%sB interp=%d compiled=%d\n' \
            "$status" "$file" "$(wc -c <"$io" | tr -d ' ')" "$rc_i" "$rc_c"
    else
        printf '%-8s %s  %s\n' "$status" "$file" "$reasons"
        [ -f "$outdir/stdout.diff" ] && sed 's/^/         /' "$outdir/stdout.diff"
    fi
    record "$status $file"
}

main() {
    local arg
    for arg in "$@"; do
        case "$arg" in
            -h | --help)
                usage
                exit 0
                ;;
            --) shift; break ;;
        esac
    done

    if [ "$#" -eq 0 ]; then
        echo "difftest: 未指定示例，使用最简单的 3 个默认示例"
        set -- "${DEFAULT_CASES[@]}"
    fi

    if ! resolve_bin; then
        echo "difftest: 缺少工具链入口，停止。" >&2
        echo "  已检查：XNULL_BIN、difftest/.bin/xnull、impl/cmd/xnull（含 overlay 构建）" >&2
        exit 1
    fi

    mkdir -p "$ART_DIR" || exit 1
    echo "difftest: 超时 ${TIMEOUT_SECONDS}s/路径，证据目录 $ART_DIR"
    echo

    for arg in "$@"; do
        if [ ! -f "$arg" ]; then
            printf '%-8s %s  路径不存在，已跳过\n' SKIP "$arg"
            skips=$((skips + 1))
            failures=$((failures + 1))
            record "SKIP $arg"
            continue
        fi
        run_case "$arg"
    done

    if [ "$total" -eq 0 ]; then
        echo
        echo "difftest: 没有可执行示例（全部跳过）"
        exit 1
    fi

    echo
    echo "汇总：MATCH=$matches MISMATCH=$mismatches TIMEOUT=$timeouts SKIP=$skips"
    if [ "$failures" -eq 0 ]; then
        echo "结果：全部 MATCH"
        exit 0
    fi
    echo "结果：存在失败项"
    exit 1
}

set -m
main "$@"
