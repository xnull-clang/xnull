# S1-04 差分测试框架（最小可用）验收单

- 任务 ID：S1-04
- 主责 / 验收人：QA-1 / 待 CEO 会签（本单为交付自检，不作为 CEO 验收签名）
- 基线 commit：见 `sha.txt`
- 改动文件：`difftest/run.sh`（新增）；`evidence/S1-04/**`（证据）
- 未改动：`impl/**`、`examples/**`、任何测试期望值
- 验收命令：见 `command.txt`
- 实际结果：3/3 MATCH，退出码 0（`stdout.txt` / `exit_code.txt`）
- 反例结果：编译路径人为多输出一行 → MISMATCH，退出码 1（`counterexample/negative-run.log`）；原始脚本复原后仍 3/3 MATCH
- 超时：单条路径 30s，超时由 watchdog 杀进程组并记 TIMEOUT
- 期望值来源：无。框架只比较解释路径与编译路径的实测 stdout/退出码，不内嵌任何期望输出（反作弊条款 3/4）
- 证据目录：`evidence/S1-04/`
- 未测项：parser-seed.xn 单次编译/解释耗时异常（>30s 未完成），不在本卡“最简单 3 个示例”范围；已登记为待查
- 结论：**通过（QA-1 自检）**
- 签名 / 时间：QA-1 / 2026-11-07 01:12
