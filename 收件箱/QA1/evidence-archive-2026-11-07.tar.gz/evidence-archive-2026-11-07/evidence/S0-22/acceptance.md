# S0-21 验收单（L1 任务验收：S0-22 B-full 独立验收）

- 任务 ID：S0-22（独立验收 S0-21 / B-full 去 Python 化）
- 主责 / 验收人：QA-1（实现者 E6，验收人 ≠ 实现者）
- 被测：E6 工作树 `wt/e6-toolchain` @ `b7be513`；候选二进制 `evidence/S0-21d/after-merge/bin/xnull`
- 前置：main `9301ed4`（P0-1/P0-2/P0-3 已合入）
- golden：`evidence/S0-22P/golden/`（QA1 在 ad70f19 自建，3 次一致；未引用 E6 evidence 作结论）
- 验收命令：见 `evidence/S0-22/command.txt`
- 实际结果：`PASS=7 FAIL=0`，退出码 0（`evidence/S0-22/stdout.txt`、`exit_code.txt`）
- 结论：**PASS（7/7）**，非“条件通过”
- 未测项：见验收报告第五节
- 签名 / 时间：QA-1 / 2026-11-07 02:00
