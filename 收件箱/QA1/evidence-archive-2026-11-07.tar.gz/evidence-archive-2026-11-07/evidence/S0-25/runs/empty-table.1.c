/* 由 impl/tools/gen_resources.py 生成（构建期产物，勿手改；S8 §5.6）。
 * 资源表按名称升序；查找为二分；空表零成本。 */
#include <stddef.h>
#include <string.h>

typedef struct {
    const char         *name;
    const unsigned char *data;
    size_t              len;
} xrt_resource;

/* 空表：无资源的工程零成本 */
size_t xrt_resource_count(void) { return 0; }

int xrt_resource_get(const char *name, size_t nlen,
                     const unsigned char **out, size_t *out_len) {
    (void)name; (void)nlen;
    *out = 0; *out_len = 0;
    return 1;
}
