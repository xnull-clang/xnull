# S0-25 会签单（L1：D1 资源子目录修正）

- 任务 ID：S0-25（D1 修正：资源子目录）
- 主责 / 会签人：E6 / QA-1（会签人 ≠ 实现者）
- 被测：`wt/e6-toolchain` @ `f826d1f`（只读）；候选二进制由该源码构建，sha256 `cd2e7f70…c2e4`
- 判据：S8 §5.6 收录/空目录/符号链接；S8 §8（PROJ-09）可复现；任务卡 D1 安全判据
- 命令：`evidence/S0-25/command.txt`
- 实际结果：fixture 9/9 PASS（合法 5 + 拒绝 4）；`build_rt.sh` exit 0；`go test ./internal/devtool ./internal/cli` exit 0
- 结论：**PASS**
- 未测项：见会签报告第四节
- 签名 / 时间：QA-1 / 2026-11-07 02:25
